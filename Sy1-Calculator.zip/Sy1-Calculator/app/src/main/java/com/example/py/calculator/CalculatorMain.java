package com.example.py.calculator;

import android.content.Intent;
import android.os.Bundle;
import android.app.Activity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import static java.lang.Math.sin;
import static java.lang.Math.cos;
import static java.lang.Math.tan;
//import static java.lang.Math.sinh;
//import static java.lang.Math.cosh;
//import static java.lang.Math.tanh;
import static java.lang.Math.log10;
//import static java.lang.Math.log;

public class CalculatorMain extends Activity {
    private TextView mShowTextView = null;
    private StringBuffer mExpressBuffer = new StringBuffer();
    private String mResult = "";  //定义空字符串mResult存储结果
    private static CalculatorMathUtil mCalculatorMathUtil = new CalculatorMathUtil(20);
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);  //启动activity
        setContentView(R.layout.activity_calculator_main);  //加载activity对应的layout
        mShowTextView = (TextView) findViewById(R.id.tv_calculator_result);  //findViewById方法获取text view内容
    }

    public void clickMe(View v) { // 点击事件监听
        if (mResult.length() > 0 && mExpressBuffer.toString().contains("=")) {  //判断有结果，有“=”,点击事件才有效
            mExpressBuffer = new StringBuffer();
        }
        Button btn = (Button) v;
        switch (btn.getId()) {
            case R.id.btn_calculator_num_0:
                if (mExpressBuffer.length() != 0 && mExpressBuffer.charAt(mExpressBuffer.length() - 1) == ')') { //索引最后一个字符为“）”，避免括号后输数字
                    break;
                }
                mExpressBuffer.append(0);
                break;
            case R.id.btn_calculator_num_1:
                if (mExpressBuffer.length() != 0 && mExpressBuffer.charAt(mExpressBuffer.length() - 1) == ')') {
                    break;
                }
                mExpressBuffer.append(1);
                break;
            case R.id.btn_calculator_num_2:
                if (mExpressBuffer.length() != 0 && mExpressBuffer.charAt(mExpressBuffer.length() - 1) == ')') {
                    break;
                }
                mExpressBuffer.append(2);
                break;
            case R.id.btn_calculator_num_3:
                if (mExpressBuffer.length() != 0 && mExpressBuffer.charAt(mExpressBuffer.length() - 1) == ')') {
                    break;
                }
                mExpressBuffer.append(3);
                break;
            case R.id.btn_calculator_num_4:
                if (mExpressBuffer.length() != 0 && mExpressBuffer.charAt(mExpressBuffer.length() - 1) == ')') {
                    break;
                }
                mExpressBuffer.append(4);
                break;
            case R.id.btn_calculator_num_5:
                if (mExpressBuffer.length() != 0 && mExpressBuffer.charAt(mExpressBuffer.length() - 1) == ')') {
                    break;
                }
                mExpressBuffer.append(5);
                break;
            case R.id.btn_calculator_num_6:
                if (mExpressBuffer.length() != 0 && mExpressBuffer.charAt(mExpressBuffer.length() - 1) == ')') {
                    break;
                }
                mExpressBuffer.append(6);
                break;
            case R.id.btn_calculator_num_7:
                if (mExpressBuffer.length() != 0 && mExpressBuffer.charAt(mExpressBuffer.length() - 1) == ')') {
                    break;
                }
                mExpressBuffer.append(7);
                break;
            case R.id.btn_calculator_num_8:
                if (mExpressBuffer.length() != 0 && mExpressBuffer.charAt(mExpressBuffer.length() - 1) == ')') {
                    break;
                }
                mExpressBuffer.append(8);
                break;
            case R.id.btn_calculator_num_9:
                if (mExpressBuffer.length() != 0 && mExpressBuffer.charAt(mExpressBuffer.length() - 1) == ')') {
                    break;
                }
                mExpressBuffer.append(9);
                break;
            case R.id.btn_calculator_num_point:
                if (mExpressBuffer.length() != 0) {
                    char c = mExpressBuffer.charAt(mExpressBuffer.length() - 1);
                    if (c >= '0' && c <= '9') {
                        mExpressBuffer.append(".");
                    }
                }
                break;
            case R.id.btn_calculator_brackets_left:  //"("
                if (mExpressBuffer.length() == 0) {  //初始可点击
                    mExpressBuffer.append("(");
                } else {
                    char c = mExpressBuffer.charAt(mExpressBuffer.length() - 1);
                    if (c == '+' || c == '-' || c == '*' || c == '/' || c == '(') {  //最后字符为运算符号或（多重括号可点击
                        mExpressBuffer.append("(");
                    }
                }
                break;
            case R.id.btn_calculator_brackets_right:  //“）”可否输入
                if (mExpressBuffer.length() != 0) {  //初始不可输入
                    char c = '\0';  //定义空字符，用于遍历mExpressBuffer
                    int n1 = 0;// '('的个数
                    int n2 = 0;// ')'的个数
                    for (int i = 0; i < mExpressBuffer.length(); i++) {
                        c = mExpressBuffer.charAt(i);
                        if (c == '(') {
                            n1++;
                        } else if (c == ')') {
                            n2++;
                        }
                    }
                    if (n2 < n1 && (c >= '0' && c <= '9' || c == ')')) {  //“（”个数多余
                        mExpressBuffer.append(")");
                    }
                }
                break;
            case R.id.btn_calculator_back_space:  //回退Del清除最后1位    StringBuffer的deleteCharAt()方法
                if (mExpressBuffer.length() != 0) {
                    mExpressBuffer.deleteCharAt(mExpressBuffer.length() - 1);
                }
                break;
            case R.id.btn_calculator_operator_0:  //清零C
                mExpressBuffer = new StringBuffer();
                mResult = "";
                break;
            case R.id.btn_calculator_operator_1:  //+
                if (mResult.length() != 0) {  //有内容即显示+
                    mExpressBuffer.append(mResult);
                    mResult = "";
                }
                if (mExpressBuffer.length() == 0) {  //无内容显示“+”作为正号
                    mExpressBuffer.append("+");
                } else {
                    char c = mExpressBuffer.charAt(mExpressBuffer.length() - 1);
                    if (c >= '0' && c <= '9' || c == ')') {
                        mExpressBuffer.append("+");
                    }
                }
                break;
            case R.id.btn_calculator_operator_2:  //-
                if (mResult.length() != 0) {
                    mExpressBuffer.append(mResult);
                    mResult = "";
                }
                if (mExpressBuffer.length() == 0) {
                    mExpressBuffer.append("-");
                } else {
                    int len = mExpressBuffer.length();
                    char c = mExpressBuffer.charAt(len - 1);
                    if (c >= '0' && c <= '9' || c == '(' || c == ')') {
                        mExpressBuffer.append("-");
                    } else if (len >= 2) {
                        c = mExpressBuffer.charAt(len - 2);
                        if (c >= '0' && c <= '9' || c == '(' || c == ')') {
                            mExpressBuffer.append("-");
                        }
                    }
                }
                break;
            case R.id.btn_calculator_operator_3:  //*
                if (mResult.length() != 0) {
                    mExpressBuffer.append(mResult);
                    mResult = "";
                }
                if (mExpressBuffer.length() != 0) {
                    char c = mExpressBuffer.charAt(mExpressBuffer.length() - 1);
                    if (c >= '0' && c <= '9' || c == ')') {
                        mExpressBuffer.append("*");
                    }
                }
                break;
            case R.id.btn_calculator_operator_4:
                if (mResult.length() != 0) {
                    mExpressBuffer.append(mResult);
                    mResult = "";
                }
                if (mExpressBuffer.length() != 0) {
                    char c = mExpressBuffer.charAt(mExpressBuffer.length() - 1);
                    if (c >= '0' && c <= '9' || c == ')') {
                        mExpressBuffer.append("/");
                    }
                }
                break;
            case R.id.btn_calculator_operator_5:
                if (mExpressBuffer.length() != 0) {  //判断表达式是否合法
                    char c = '\0';  //定义空字符,用于遍历字输入的表达式
                    int n1 = 0; // '('的个数
                    int n2 = 0; // ')'的个数
                    for (int i = 0; i < mExpressBuffer.length(); i++) {
                        c = mExpressBuffer.charAt(i);
                        if (c == '(') {
                            n1++;
                        } else if (c == ')') {
                            n2++;
                        }
                    }
                    if (n1 == n2 && (c >= '0' && c <= '9' || c == ')')) {  //括号数量相等,是数字,是“)”可以计算
                        mExpressBuffer.append("=");
                        try {
                            mResult = mCalculatorMathUtil.getResult(mExpressBuffer.toString());
                            mExpressBuffer.append(mResult);
                        } catch (Exception e1) {
                            mExpressBuffer.deleteCharAt(mExpressBuffer.length() - 1);
                            //Toast.makeText(this, "表达式错误", Toast.LENGTH_LONG).show();
                            mExpressBuffer.append("表达式错误！");
                        }

                    }
                }
                break;
            case R.id.btn_calculator_vector_1:  //sin
                if (mExpressBuffer.length() != 0) {
                    double n1 = Double.parseDouble(mExpressBuffer.toString());
                    mExpressBuffer = new StringBuffer();
                    mExpressBuffer.append("sin(" + n1 + ")=" + sin(n1) + "");
                }
                break;
            case R.id.btn_calculator_vector_2:  //cos
                if (mExpressBuffer.length() != 0) {
                    double n1 = Double.parseDouble(mExpressBuffer.toString());
                    mExpressBuffer = new StringBuffer();
                    mExpressBuffer.append("cos(" + n1 + ")=" + cos(n1) + "");
                }
                break;
            case R.id.btn_calculator_vector_3:  //^^^指数运算
                if (mResult.length() != 0) {
                    mExpressBuffer.append(mResult);
                    mResult = "";
                }
                if (mExpressBuffer.length() != 0) {
                    char c = mExpressBuffer.charAt(mExpressBuffer.length() - 1);
                    if (c >= '0' && c <= '9' || c == ')') {
                        mExpressBuffer.append("^");
                    }
                }
                break;
            case R.id.btn_calculator_vector_4:  //tan
                if (mExpressBuffer.length() != 0) {
                    double n1 = Double.parseDouble(mExpressBuffer.toString());
                    mExpressBuffer = new StringBuffer();
                    if((n1+90)%180 == 0){  //90的奇数倍数不可计算
                        mExpressBuffer.append("请输入合法运算数！");
                    }
                    else
                        mExpressBuffer.append("tan(" + n1 + ")=" + tan(n1) + "");
                }
                break;
            case R.id.btn_calculator_vector_5:  //log10
                if (mExpressBuffer.length() != 0) {
                    double n1 = Double.parseDouble(mExpressBuffer.toString());
                    double n2 = Double.parseDouble(mExpressBuffer.toString());
                    mExpressBuffer = new StringBuffer();
                    mExpressBuffer.append("log10(" + n1 + ")=" + log10(n1) + "");
                }
                break;
            case R.id.btn_calculator_exchange_1:  //单位换算
                Intent intentdw = new Intent(CalculatorMain.this,UnitConversion.class);  //显式intent
                startActivity(intentdw);
                break;
            case R.id.btn_calculator_exchange_2:  //进制转换
                Intent intentjz = new Intent(CalculatorMain.this, HexadecimalConversion.class);  //显式intent
                startActivity(intentjz);
                break;
            default:
                break;
        }
        mShowTextView.setText(mExpressBuffer.toString());  //输出字符串
    }

}

