package com.example.yzy.notebook;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.ContextMenu;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    static NotesDBHelper mDbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        //为ListView注册上下文菜单
        ListView list = (ListView) findViewById(R.id.lstNotes);
        registerForContextMenu(list);


        //创建SQLiteOpenHelper对象，注意第一次运行时，此时数据库并没有被创建
        mDbHelper = new NotesDBHelper(this);  //new一个对象 会调用onCreat方法 传去指针this

        // 在列表显示全部单词
        ArrayList<Map<String, String>> items = getAll();
        setNotesListView(items);
    }

    @Override
    protected void onDestroy () {
        super.onDestroy();
        mDbHelper.close();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {//创建menu_main
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_insert) { //新增事件
            InsertDialog();
            return true;
        } else if (id == R.id.action_search) {  //查找事件
            SearchDialog();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {  //创建ontextmenu_noteslistview
        getMenuInflater().inflate(R.menu.contextmenu_noteslistview, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {  //选择了某菜单之后如何做
        TextView textId = null;
        TextView textNote = null;
        TextView textTime = null;
        TextView textAuthor = null;
        AdapterView.AdapterContextMenuInfo info = null;
        View itemView = null;
        switch (item.getItemId()) {
            case R.id.action_delete: //删除事件
                info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();  //获得该事件的id
                itemView = info.targetView;  //获得单词所在的viev
                textId = (TextView) itemView.findViewById(R.id.textId);  //找到textid可知用户选择的事件
                if (textId != null) {
                    String strId = textId.getText().toString();
                    DeleteDialog(strId);
                }
                break;

            case R.id.action_update://修改事件
                info = (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
                itemView = info.targetView;
                textId = (TextView) itemView.findViewById(R.id.textId);
                textNote = (TextView) itemView.findViewById(R.id.textViewNote);
                textTime = (TextView) itemView.findViewById(R.id.textViewTime);
                //获取系统时间并显示
                Date date = new Date();
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
                String dateString = sdf.format(date);
                textTime.setText(dateString);
                textAuthor = (TextView) itemView.findViewById(R.id.textViewAuthor);
                if (textId != null && textNote != null && textTime != null && textAuthor != null) {
                    String strId = textId.getText().toString();
                    String strNote = textNote.getText().toString();
                    String strTime = textTime.getText().toString();
                    String strAuthor = textAuthor.getText().toString();
                    UpdateDialog(strId, strNote, strTime, strAuthor);  // UpdateDialog自定义的对话框
                }
                break;
        }
        return true;
    }

    private void setNotesListView(ArrayList<Map<String, String>> items) {
        SimpleAdapter adapter = new SimpleAdapter(this, items, R.layout.item,  //定义方法SimpleAdapter 上下文 参数来源 item
                new String[]{Notes.Note._ID, Notes.Note.COLUMN_NAME_NOTE, Notes.Note.COLUMN_NAME_TIME, Notes.Note.COLUMN_NAME_AUTHOR},
                new int[]{R.id.textId, R.id.textViewNote, R.id.textViewTime, R.id.textViewAuthor});  //定义映射关系
        ListView list = (ListView) findViewById(R.id.lstNotes);
        list.setAdapter(adapter);
    }

    //使用Sql语句新增事件
    private void InsertUserSql(String strNote, String strTime, String strAuthor){
        String sql="insert into  notes(note,time,author) values(?,?,?)";
        //Gets the data repository in write mode*/
        SQLiteDatabase db = mDbHelper.getWritableDatabase();
        db.execSQL(sql,new String[]{strNote,strTime,strAuthor});
    }

    //使用方法新增事件
    private void Insert(String strNote, String strTime, String strAuthor) {
        //Gets the data repository in write mode
        SQLiteDatabase db = mDbHelper.getWritableDatabase();
        // Create a new map of values, where column names are the keys
        ContentValues values = new ContentValues();
        values.put(Notes.Note.COLUMN_NAME_NOTE, strNote);
        values.put(Notes.Note.COLUMN_NAME_TIME, strTime);
        values.put(Notes.Note.COLUMN_NAME_AUTHOR, strAuthor);
        // Insert the new row, returning the primary key value of the new row
        long newRowId;
        newRowId = db.insert(Notes.Note.TABLE_NAME,null,values);
    }

    //新增对话框
    private void InsertDialog() {
        final TableLayout tableLayout = (TableLayout) getLayoutInflater().inflate(R.layout.insert, null);
        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        String dateString = sdf.format(date);
        ((EditText)tableLayout.findViewById(R.id.txtTime)).setText(dateString);
        //textTime.setText(dateString);
        new AlertDialog.Builder(this)
                .setTitle("添加事件")//标题
                .setView(tableLayout)//设置视图
                // 确定按钮及其动作
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String strNote = ((EditText) tableLayout.findViewById(R.id.txtNote)).getText().toString();
                        String strTime = ((EditText) tableLayout.findViewById(R.id.txtTime)).getText().toString();
                        String strAuthor = ((EditText) tableLayout.findViewById(R.id.txtAuthor)).getText().toString();

                        //既可以使用Sql语句插入，也可以使用使用insert方法插入
                        // InsertUserSql(strNote, strTime, strAuthor);
                        Insert(strNote, strTime, strAuthor);
                        ArrayList<Map<String, String>> items = getAll();  // getAll();显示全部单词
                        setNotesListView(items);
                    }
                })

                //取消按钮及其动作
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                })
                .create()//创建对话框
                .show();//显示对话框
    }

    //使用Sql语句删除事件
    private void DeleteUseSql(String strId) {
        String sql="delete from notes where _id='"+strId+"'";
        //Gets the data repository in write mode*/
        SQLiteDatabase db = mDbHelper.getReadableDatabase();
        db.execSQL(sql);
    }

    //删除事件
    private void Delete(String strId) {
        SQLiteDatabase db = mDbHelper.getReadableDatabase();
        // 定义where子句
        String selection = Notes.Note._ID + " = ?";
        // 指定占位符对应的实际参数
        String[] selectionArgs = {strId};
        // Issue SQL statement.
        db.delete(Notes.Note.TABLE_NAME, selection, selectionArgs);
    }

    //删除对话框
    private void DeleteDialog(final String strId){
        new AlertDialog.Builder(this)
                .setTitle("删除事件")
                .setMessage("确定删除该事件?")
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //既可以使用Sql语句删除，也可以使用使用delete方法删除
                        DeleteUseSql(strId);
                        //Delete(strId);
                        setNotesListView(getAll());
                    }
                })
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                })
                .create()//创建对话框
                .show();//显示对话框
    }

    //使用Sql语句修改事件
    private void UpdateUseSql(String strId,String strNote, String strTime, String strAuthor) {
        SQLiteDatabase db = mDbHelper.getReadableDatabase();
        String sql="update notes set note=?,time=?,author=? where _id=?";
        db.execSQL(sql, new String[]{strNote, strTime, strAuthor,strId});
    }

    //使用方法修改事件
    private void Update(String strId,String strNote, String strTime, String strAuthor) {
        SQLiteDatabase db = mDbHelper.getReadableDatabase();
        // New value for one column
        ContentValues values = new ContentValues();
        values.put(Notes.Note.COLUMN_NAME_NOTE, strNote);
        values.put(Notes.Note.COLUMN_NAME_TIME, strTime);
        values.put(Notes.Note.COLUMN_NAME_AUTHOR, strAuthor);
        String selection = Notes.Note._ID + " = ?";
        String[] selectionArgs = {strId};
        int count = db.update(Notes.Note.TABLE_NAME,values,selection,selectionArgs);
    }

    //修改对话框
    private void UpdateDialog(final String strId, final String strNote, final String strTime, final String strAuthor) {
        final TableLayout tableLayout = (TableLayout) getLayoutInflater().inflate(R.layout.insert, null);
        ((EditText)tableLayout.findViewById(R.id.txtNote)).setText(strNote);
        ((EditText)tableLayout.findViewById(R.id.txtTime)).setText(strTime);
        ((EditText)tableLayout.findViewById(R.id.txtAuthor)).setText(strAuthor);
        new AlertDialog.Builder(this)
                .setTitle("修改事件")//标题
                .setView(tableLayout)//设置视图
                // 确定按钮及其动作
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String strNewNote = ((EditText) tableLayout.findViewById(R.id.txtNote)).getText().toString();
                        String strNewTime = ((EditText) tableLayout.findViewById(R.id.txtTime)).getText().toString();
                        String strNewAuthor = ((EditText) tableLayout.findViewById(R.id.txtAuthor)).getText().toString();
                        //既可以使用Sql语句更新，也可以使用使用update方法更新
                        //UpdateUseSql(strId, strNewNote, strNewTime, strNewAuthor);
                        Update(strId, strNewNote, strNewTime, strNewAuthor);
                        setNotesListView(getAll());
                    }
                })
                //取消按钮及其动作
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                })
                .create()//创建对话框
                .show();//显示对话框
    }

    //使用Sql语句查找
    private ArrayList<Map<String, String>> SearchUseSql(String strNoteSearch) {
        SQLiteDatabase db = mDbHelper.getReadableDatabase();
        String sql="select * from words where word like ? order by word desc";
        Cursor c=db.rawQuery(sql,new String[]{"%"+strNoteSearch+"%"});
        return ConvertCursor2List(c);
    }

    //使用query方法查找
    private ArrayList<Map<String, String>> Search(String strNoteSearch) {
        SQLiteDatabase db = mDbHelper.getReadableDatabase();
        String[] projection = {Notes.Note._ID, Notes.Note.COLUMN_NAME_NOTE, Notes.Note.COLUMN_NAME_TIME, Notes.Note.COLUMN_NAME_AUTHOR};
        String sortOrder = Notes.Note.COLUMN_NAME_NOTE + " DESC";
        String selection = Notes.Note.COLUMN_NAME_NOTE + " LIKE ?";
        String[] selectionArgs = {"%"+strNoteSearch+"%"};
        Cursor c = db.query(Notes.Note.TABLE_NAME,
                // The table to query
                projection,
                // The columns to return
                selection,
                // The columns for the WHERE clause
                selectionArgs,
                // The values for the WHERE clause
                null,
                // don't group the rows
                null,
                // don't filter by row groups
                sortOrder
                // The sort order
                );
        return ConvertCursor2List(c);
    }

    //查询对话框
    private void SearchDialog() {
        final TableLayout tableLayout = (TableLayout) getLayoutInflater().inflate(R.layout.searchterm, null);
        new AlertDialog.Builder(this)
                .setTitle("查询事件")//标题
                .setView(tableLayout)//设置视图
                // 确定按钮及其动作
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String txtSearchNote=((EditText)tableLayout.findViewById(R.id.txtSearchNote)).getText().toString();
                        ArrayList<Map<String, String>> items=null;
                        //既可以使用Sql语句查询，也可以使用方法查询
                        //items=SearchUseSql(txtSearchNote);
                        items=Search(txtSearchNote);
                        if(items.size()>0) {
                            Bundle bundle=new Bundle();
                            bundle.putSerializable("result",items);
                            Intent intent=new Intent(MainActivity.this,SearchActivity.class);
                            intent.putExtras(bundle);
                            startActivity(intent);
                        }else
                            Toast.makeText(MainActivity.this,"没有该事件",Toast.LENGTH_LONG).show();
                    }
                })
        //取消按钮及其动作
        .setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        })
        .create()//创建对话框
        .show();//显示对话框
    }

    public static ArrayList<Map<String, String>> ConvertCursor2List(Cursor cursor) {
        ArrayList<Map<String, String>> result = new ArrayList<>();
        while (cursor.moveToNext()) {
            Map<String, String> map = new HashMap<>();
            map.put(Notes.Note._ID, String.valueOf(cursor.getInt(0)));
            map.put(Notes.Note.COLUMN_NAME_NOTE, cursor.getString(1));
            map.put(Notes.Note.COLUMN_NAME_TIME, cursor.getString(2));
            map.put(Notes.Note.COLUMN_NAME_AUTHOR, cursor.getString(3));
            result.add(map);
        }
        return result;
    }

    public static ArrayList<Map<String, String>> getAll() {
        SQLiteDatabase db = mDbHelper.getReadableDatabase();
        String[] projection = {
                Notes.Note._ID,
                Notes.Note.COLUMN_NAME_NOTE,
                Notes.Note.COLUMN_NAME_TIME,
                Notes.Note.COLUMN_NAME_AUTHOR
        };
        //排序
        String sortOrder = Notes.Note.COLUMN_NAME_NOTE + " DESC";
        Cursor c = db.query(
                Notes.Note.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                sortOrder
        );
        return ConvertCursor2List(c);
    }
}