package com.example.yzy.notebook;


import android.provider.BaseColumns;

public class Notes {
    public Notes() {

    }

    public static abstract class Note implements BaseColumns {
        public static final String TABLE_NAME="notes";
        public static final String COLUMN_NAME_NOTE="note";//列：事件
        public static final String COLUMN_NAME_TIME="time";//列：时间
        public static final String COLUMN_NAME_AUTHOR="author";//事件作者
    }

}
